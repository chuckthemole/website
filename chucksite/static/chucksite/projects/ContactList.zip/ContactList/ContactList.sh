java -jar ContactList.jar
