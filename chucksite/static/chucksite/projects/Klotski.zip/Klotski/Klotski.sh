java -jar Klotski.jar
